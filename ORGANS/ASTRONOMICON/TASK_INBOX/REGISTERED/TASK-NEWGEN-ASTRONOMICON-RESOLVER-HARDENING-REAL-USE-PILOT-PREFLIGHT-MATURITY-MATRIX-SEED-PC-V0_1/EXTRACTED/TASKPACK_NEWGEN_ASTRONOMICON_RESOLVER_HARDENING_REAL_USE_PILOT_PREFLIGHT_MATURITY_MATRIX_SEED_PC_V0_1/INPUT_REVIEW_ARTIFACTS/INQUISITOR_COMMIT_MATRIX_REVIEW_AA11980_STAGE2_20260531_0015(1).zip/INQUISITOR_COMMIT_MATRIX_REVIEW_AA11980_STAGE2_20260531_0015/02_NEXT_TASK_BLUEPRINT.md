# Next Task Blueprint - Resolver Hardening and Real-Use Pilot Preflight

## Task ID

`TASK-NEWGEN-ASTRONOMICON-RESOLVER-HARDENING-AND-REAL-USE-PILOT-PREFLIGHT-PC-V0_1`

## Goal

Turn Stage2 from a synthetic/script-first form into a preflight-ready real-use corridor where Owner can provide a task ID and `start task`, and Servitor can resolve the registered task deterministically.

## Required inputs

- Stage2 bundle commit 5241843
- Finalization/meta commit aa11980
- Inquisitor review ZIP for aa11980
- Speculum technical red-team review for aa11980, if available

## Acceptance gates

- Resolve current expected task by ID from registry.
- Prove missing/duplicate/corrupt registry cases with fixtures.
- Produce Owner-friendly RU diagnostics for blocked intake.
- Classify pre-existing dirty files and prove they are outside scope or close them.
- Produce TASK_START_ACK from a registered task using only task ID and start task phrase.
- Keep CAP_NO_WARP_RUNTIME and CAP_NO_IDE_VISUAL_RELEASE_YET active.

## Forbidden scope

- Do not build IDE visual release in this task.
- Do not claim WARP runtime.
- Do not mass-migrate unrelated legacy receipts.
- Do not hide dirty worktree evidence.

## Required outputs

- `resolver_hardening_report.md`
- `real_use_pilot_preflight_receipt.json`
- `dirty_state_scope_classification.json`
- `task_start_ack_real_use_candidate.json`
- `owner_diagnostics_ru.md`
- `hard_red_team_verdict.json`
- `final_owner_summary_ru.md`
