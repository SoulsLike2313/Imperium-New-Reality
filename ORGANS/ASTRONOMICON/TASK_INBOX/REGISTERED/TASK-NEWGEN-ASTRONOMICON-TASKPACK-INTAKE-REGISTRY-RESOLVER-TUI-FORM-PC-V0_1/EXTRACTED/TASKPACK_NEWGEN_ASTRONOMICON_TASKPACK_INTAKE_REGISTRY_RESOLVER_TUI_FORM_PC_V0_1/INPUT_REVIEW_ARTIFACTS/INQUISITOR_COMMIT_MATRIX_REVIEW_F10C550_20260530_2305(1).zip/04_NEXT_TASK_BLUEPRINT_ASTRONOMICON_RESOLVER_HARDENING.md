# Next Task Blueprint: TASK-NEWGEN-ASTRONOMICON-RESOLVER-HARDENING-V0_1

## Purpose
Harden the Astronomicon task ID resolver and task-entry admission corridor created in Stage 1.

## Starting evidence
- Bundle head: `620f11d402fd3aa3c330ac37108e1e4104c15f52`
- Finalization head: `f10c55079274035df89ac076df2bc8cd82916a51`
- Stage verdict: `PASS_WITH_WARNINGS`

## Scope
Allowed:
- `IMPERIUM_NEW_GENERATION/ORGANS/ASTRONOMICON/TASK_ENTRY_CORRIDOR/**`
- `IMPERIUM_NEW_GENERATION/ORGANS/ASTRONOMICON/TASK_INBOX/**`
- `IMPERIUM_NEW_GENERATION/ORGANS/ASTRONOMICON/TASK_REGISTRY/**`
- `IMPERIUM_NEW_GENERATION/ORGANS/ASTRONOMICON/REPORTS/TASK-NEWGEN-ASTRONOMICON-RESOLVER-HARDENING-V0_1/**`
- minimal script under `scripts/` if needed.

Forbidden:
- No WARP claims.
- No IDE visual release.
- No broad legacy receipt producer migration.
- No fake buttons or unproven live automation.

## Required negative fixtures
1. Missing task ID.
2. Duplicate task ID.
3. Taskpack exists but route manifest missing.
4. Route manifest points outside allowed scope.
5. Owner says `start task` but task ID absent.
6. Taskpack present but organ read-first ACK missing.
7. Malformed taskpack admission contract.
8. Registry entry exists but inbox artifact missing.

## Required outputs
- `resolver_hardening_report.md`
- `task_id_resolver_validation_receipt.json`
- `task_entry_negative_fixture_report.json`
- `task_start_ack_integrity_receipt.json`
- `capability_split_receipt.json`
- `claim_ledger.jsonl`
- `hard_red_team_verdict.json`
- `final_owner_summary_ru.md`
- `commit_push_receipt.json`

## Acceptance
`PASS_WITH_WARNINGS` only. Clean PASS is forbidden until a real Owner task is started by task ID through Astronomicon and independently reviewed.
