# Next Pipeline Blueprint

Task: `TASK-NEWGEN-STAGE3-ASTRONOMICON-BOOTSTRAP-HARDENING-UTF8-PREFLIGHT-PC-V0_1`

Закрыть найденную Stage3 bootstrap проблему: UTF-8 BOM / missing/invalid Astronomicon templates должны ловиться до admission и чиниться script-first, а не вручную.

## Must create
- `astronomicon_bootstrap_preflight_v0_1.py`
- `utf8_bom_detector_fixture_set`
- `template_pair_presence_fixture_set`
- `bootstrap_preflight_receipt.json`
- `stage3_bootstrap_hardening_report.md`
- `hard_red_team_verdict.json`
- `final_owner_summary_ru.md`

## PASS gates
- Detect BOM in JSON templates.
- Detect missing TASK_ROUTE_MANIFEST_TEMPLATE.json and TASK_START_ACK_TEMPLATE.json.
- Produce actionable RU/EN diagnostics without mojibake.
- Positive fixture passes after repair.
- No WARP/IDE/freelance production claims.

## Forbidden
- Do not move to IDE visual release.
- Do not claim WARP runtime.
- Do not rewrite broad Astronomicon architecture without scope.
- Do not hide manual repairs.
