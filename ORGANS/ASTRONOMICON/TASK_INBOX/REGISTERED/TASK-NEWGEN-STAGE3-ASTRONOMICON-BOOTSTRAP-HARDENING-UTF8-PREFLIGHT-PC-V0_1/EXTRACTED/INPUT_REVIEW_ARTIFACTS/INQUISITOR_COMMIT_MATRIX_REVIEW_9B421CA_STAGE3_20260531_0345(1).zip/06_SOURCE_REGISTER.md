# Source Register

{
  "public_sources": [
    {
      "kind": "github_commit",
      "url": "https://github.com/SoulsLike2313/Imperium-/commit/9b421cabc2cf781a47bf90d31c233fe96e6d8fbd",
      "used_for": "commit size/message/file tree"
    },
    {
      "kind": "raw_json",
      "path": "hard_red_team_verdict.json",
      "used_for": "caps/final verdict"
    },
    {
      "kind": "raw_json",
      "path": "EIGHT_ORGAN_PARTICIPATION_RUNTIME_RECEIPT.json",
      "used_for": "8 organ participation"
    },
    {
      "kind": "raw_json",
      "path": "REAL_USE_MICROPILOT_READINESS_SNAPSHOT.json",
      "used_for": "real-use micropilot snapshot"
    },
    {
      "kind": "raw_json",
      "path": "efficiency_delta_receipt.json",
      "used_for": "efficiency delta"
    },
    {
      "kind": "raw_json",
      "path": "commit_push_receipt.json",
      "used_for": "pending finalization warning"
    },
    {
      "kind": "raw_md",
      "path": "final_owner_summary_ru.md",
      "used_for": "pending final fields warning"
    },
    {
      "kind": "raw_json",
      "path": "stage3_bootstrap_repair_finding.json",
      "used_for": "BOM/bootstrap finding"
    }
  ],
  "uploaded_plan": "EIGHT_ORGAN_MOBILIZATION_ASTRONOMICON_ENTRY_IDE_RELEASE_PLAN_V0_1.md",
  "limitations": [
    "No local git clone/replay in this environment.",
    "Raw GitHub evidence and user screenshot are treated as bounded evidence, not local runtime proof."
  ]
}