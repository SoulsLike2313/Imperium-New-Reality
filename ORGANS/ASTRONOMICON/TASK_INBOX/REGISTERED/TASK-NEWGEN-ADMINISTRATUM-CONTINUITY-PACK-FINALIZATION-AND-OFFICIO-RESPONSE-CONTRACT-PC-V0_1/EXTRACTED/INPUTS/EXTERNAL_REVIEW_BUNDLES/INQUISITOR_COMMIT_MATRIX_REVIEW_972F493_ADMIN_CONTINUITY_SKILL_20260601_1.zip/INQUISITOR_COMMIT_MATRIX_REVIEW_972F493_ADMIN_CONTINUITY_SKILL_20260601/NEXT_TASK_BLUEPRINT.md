# Next Task Blueprint

## TASK_ID

`TASK-NEWGEN-ADMINISTRATUM-CONTINUITY-PACK-EXTERNAL-FINALIZATION-RECEIPT-AND-FRESH-HANDOFF-REPLAY-PC-V0_1`

## Purpose

Close the continuity pack stale/off-by-one receipt problem without expanding scope.

## Required actions

1. Start from current clean HEAD after `972f493`.
2. Run Administratum Continuity Pack Skill again or run a verifier against the existing pack.
3. Produce an external finalization receipt for the reviewed/final head.
4. Ensure the continuity manifest either:
   - reflects final clean repo truth, or
   - explicitly declares itself as a pre-finalization snapshot with a paired post-finalization receipt.
5. Verify ZIP readability and SHA256 from final head.
6. Keep private data exclusion policy allowlist-only.
7. Do not claim IDE/WARP/VM route proof.

## Required outputs

- `continuity_pack_finalization_receipt.json`
- `continuity_pack_replay_receipt.json`
- `continuity_pack_manifest_postpush_check.json`
- `private_data_exclusion_recheck.json`
- `mechanicus_validation_receipt.json`
- `claim_ledger.jsonl`
- `hard_red_team_verdict.json`
- `commit_push_receipt.json`
- `final_owner_summary_ru.md`

## PASS gates

- No stale `commit_push_receipt`.
- No `WARN_NOT_PUSHED` if commit/push actually occurred.
- No fake clean PASS if any manifest still carries pre-finalization dirty state.
- Keep global caps visible.
