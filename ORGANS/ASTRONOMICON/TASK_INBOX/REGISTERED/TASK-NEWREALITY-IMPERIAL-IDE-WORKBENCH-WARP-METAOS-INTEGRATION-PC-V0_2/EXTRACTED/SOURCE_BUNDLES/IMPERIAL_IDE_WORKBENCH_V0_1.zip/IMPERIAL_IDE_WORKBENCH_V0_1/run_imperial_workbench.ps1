<#
.SYNOPSIS
    IMPERIAL IDE :: MECHANICUS WORKBENCH launcher (V0.1)
.DESCRIPTION
    Single entry point on Windows. Detects the repo root, picks a surface
    (GUI / TUI), and can start the servitor capsule supervisor.
.PARAMETER Surface
    gui (default) | tui | supervisor
.PARAMETER Root
    Repo root. Defaults to env IMPERIUM_ROOT, else auto-detect, else sample mode.
.PARAMETER AllowReal
    Enable real tool dispatch (off by default; dry-run is the safe default).
.EXAMPLE
    pwsh ./run_imperial_workbench.ps1
    pwsh ./run_imperial_workbench.ps1 -Surface tui
    pwsh ./run_imperial_workbench.ps1 -Surface supervisor -AllowReal
#>
[CmdletBinding()]
param(
    [ValidateSet('gui', 'tui', 'supervisor')]
    [string]$Surface = 'gui',
    [string]$Root = $env:IMPERIUM_ROOT,
    [switch]$AllowReal
)
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot

$python = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $python) { $python = (Get-Command python3 -ErrorAction SilentlyContinue) }
if (-not $python) { Write-Error 'Python 3.10+ is required on PATH.'; exit 1 }

if ($Root) { $env:IMPERIUM_ROOT = $Root }
if ($AllowReal) { $env:IMPERIUM_ALLOW_REAL = '1' }

Write-Host ''
Write-Host '  \u2042  IMPERIAL IDE :: MECHANICUS WORKBENCH' -ForegroundColor Magenta
Write-Host "     surface = $Surface   root = $($env:IMPERIUM_ROOT)   real = $AllowReal" -ForegroundColor DarkGray
Write-Host ''

switch ($Surface) {
    'gui'        { & $python.Source (Join-Path $here 'GUI/imperial_gui_workbench.py') }
    'tui'        { & $python.Source (Join-Path $here 'TUI/imperial_tui.py') }
    'supervisor' {
        $sup = Join-Path $here 'SERVITORS/servitor_capsule_supervisor.ps1'
        if ($AllowReal) { & $sup -AllowReal } else { & $sup }
    }
}
