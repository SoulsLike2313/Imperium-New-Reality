# СНАЧАЛА ПРОЧТИ — 30 секунд

1. Распакуй архив.
2. Открой PowerShell в папке `IMPERIAL_IDE_WORKBENCH_V0_1`.
3. Запусти GUI:
   ```powershell
   pwsh ./run_imperial_workbench.ps1
   ```
   (или двойной клик `run_imperial_workbench.cmd`)

Откроется окно в стиле purple dark nebula metallic. Без репо будет SAMPLE-режим.

## Чтобы привязать к реальному репо
```powershell
$env:IMPERIUM_ROOT = 'E:\IMPERIUM_NEW_GENERATION_NEW_REALITY'
pwsh ./run_imperial_workbench.ps1
```
Статусбар покажет `bridge: LIVE`, если нашёл органный мост Механикуса.

## Сервиторы в капсулах
```powershell
pwsh ./run_imperial_workbench.ps1 -Surface supervisor
```
Команды: `s` статус, `d` раздать всем, `f <id> <задача>` адресно, `q` выход.

Всё по умолчанию безопасно (dry-run). Подробности — в README_OWNER_RU.md.
