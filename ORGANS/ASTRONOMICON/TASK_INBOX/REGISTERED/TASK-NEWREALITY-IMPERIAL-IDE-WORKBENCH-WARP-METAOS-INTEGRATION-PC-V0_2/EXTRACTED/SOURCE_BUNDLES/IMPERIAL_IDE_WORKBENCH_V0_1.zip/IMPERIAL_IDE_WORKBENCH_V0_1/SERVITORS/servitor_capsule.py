#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SERVITOR CAPSULE  (V0.1) -- standalone task-runner for ONE servitor session.

WHY A SEPARATE PROCESS PER CAPSULE:
  - Isolation: one servitor's crash / rate-limit / hang never blocks the others.
  - Parallelism: run 2-3 capsules so work continues while one capsule cools down.
  - Control: the GUI/TUI or the PowerShell supervisor can start, stop, and feed
    each capsule independently over a simple JSONL task file.

PROTOCOL (file-based, dependency-free):
  - Tasks are appended as JSON lines to  <queue_dir>/<capsule_id>.tasks.jsonl
  - Results are appended to              <queue_dir>/<capsule_id>.results.jsonl
  - A heartbeat is written to            <queue_dir>/<capsule_id>.state.json

SAFETY:
  - Dry-run by default. Real CLI dispatch only when --allow-real is passed AND a
    command template is configured. Never runs an arbitrary shell string.

RUN:
  python servitor_capsule.py --capsule CAP-ALPHA --queue-dir ./_queue
  python servitor_capsule.py --capsule CAP-ALPHA --queue-dir ./_queue --allow-real
"""
import argparse
import json
import os
import time
import subprocess
from datetime import datetime


def now():
    return datetime.utcnow().isoformat() + "Z"


def write_state(state_path, payload):
    tmp = state_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, state_path)


def read_new_tasks(tasks_path, offset):
    if not os.path.isfile(tasks_path):
        return [], offset
    out = []
    with open(tasks_path, "r", encoding="utf-8") as fh:
        fh.seek(offset)
        for line in fh:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    out.append({"task": line})
        offset = fh.tell()
    return out, offset


def dispatch(task, organ, command_template, root, allow_real, cooldown, last_ts):
    gap = time.time() - last_ts[0]
    if gap < cooldown:
        time.sleep(cooldown - gap)
    last_ts[0] = time.time()
    text = task.get("task", "")
    if command_template and allow_real and root:
        cmd = [a.replace("{task}", text).replace("{root}", root)
               for a in command_template]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True,
                                  timeout=task.get("timeout", 180), cwd=root)
            return {"ts": now(), "task": text, "mode": "REAL",
                    "rc": proc.returncode, "out": (proc.stdout or "")[-4000:],
                    "err": (proc.stderr or "")[-1000:]}
        except Exception as exc:
            return {"ts": now(), "task": text, "mode": "REAL", "rc": -1,
                    "out": "", "err": "error: %s" % exc}
    return {"ts": now(), "task": text, "mode": "DRY_RUN", "rc": 0,
            "out": "DRY_RUN: %s would handle '%s'" % (organ, text), "err": ""}


def main():
    ap = argparse.ArgumentParser(description="Imperial servitor capsule runner")
    ap.add_argument("--capsule", required=True)
    ap.add_argument("--queue-dir", default="./_queue")
    ap.add_argument("--config", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "capsules.config.json"))
    ap.add_argument("--root", default=os.environ.get("IMPERIUM_ROOT"))
    ap.add_argument("--allow-real", action="store_true")
    ap.add_argument("--poll", type=float, default=0.5)
    ap.add_argument("--once", action="store_true", help="drain queue once then exit")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as fh:
        cfg = json.load(fh)
    spec = next((cap for cap in cfg["capsules"]
                 if cap["capsule_id"] == args.capsule), None)
    if not spec:
        raise SystemExit("Unknown capsule id: %s" % args.capsule)

    os.makedirs(args.queue_dir, exist_ok=True)
    tasks_path = os.path.join(args.queue_dir, "%s.tasks.jsonl" % args.capsule)
    results_path = os.path.join(args.queue_dir, "%s.results.jsonl" % args.capsule)
    state_path = os.path.join(args.queue_dir, "%s.state.json" % args.capsule)

    organ = spec.get("organ", "OFFICIO_AGENTIS")
    template = spec.get("command_template", [])
    cooldown = spec.get("rate_limit_cooldown_s", 8)
    offset = 0
    done = 0
    last_ts = [0.0]
    print("[capsule %s] online :: organ=%s allow_real=%s" % (
        args.capsule, organ, args.allow_real))
    write_state(state_path, {"capsule": args.capsule, "organ": organ,
                             "state": "WAITING", "done": done, "ts": now()})
    try:
        while True:
            tasks, offset = read_new_tasks(tasks_path, offset)
            for task in tasks:
                write_state(state_path, {"capsule": args.capsule, "organ": organ,
                                         "state": "RUNNING", "done": done,
                                         "current": task.get("task"), "ts": now()})
                result = dispatch(task, organ, template, args.root,
                                  args.allow_real, cooldown, last_ts)
                with open(results_path, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps(result, ensure_ascii=False) + "\n")
                done += 1
                print("[capsule %s] %s rc=%s :: %s" % (
                    args.capsule, result["mode"], result["rc"],
                    result["out"][:80]))
            write_state(state_path, {"capsule": args.capsule, "organ": organ,
                                     "state": "WAITING", "done": done, "ts": now()})
            if args.once:
                break
            time.sleep(args.poll)
    except KeyboardInterrupt:
        print("\n[capsule %s] shutdown" % args.capsule)
    write_state(state_path, {"capsule": args.capsule, "organ": organ,
                             "state": "IDLE", "done": done, "ts": now()})


if __name__ == "__main__":
    main()
