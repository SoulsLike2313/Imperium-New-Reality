<#
.SYNOPSIS
    Imperial IDE :: Servitor Capsule Supervisor (V0.1)

.DESCRIPTION
    Spawns and monitors 2-3 servitor capsules as separate PowerShell-managed
    processes on Windows. Each capsule runs servitor_capsule.py with its own
    task queue. The supervisor keeps them alive (restart-on-exit), shows a
    live status board, and lets you fan a task out to every capsule.

    WHY POWERSHELL HERE:
      - Native Windows process orchestration (Start-Process, job control).
      - No external dependency; ships with Windows.
      - This is the "capsule rack" controller you can also drive from the GUI.

.PARAMETER Capsules
    Capsule ids to supervise. Default: CAP-ALPHA, CAP-BETA, CAP-GAMMA

.PARAMETER QueueDir
    Directory for the file-based task/result/state queues.

.PARAMETER AllowReal
    Pass real execution through to the capsules (requires configured templates).

.EXAMPLE
    pwsh ./servitor_capsule_supervisor.ps1
    pwsh ./servitor_capsule_supervisor.ps1 -Capsules CAP-ALPHA,CAP-BETA -AllowReal
#>
[CmdletBinding()]
param(
    [string[]]$Capsules = @('CAP-ALPHA', 'CAP-BETA', 'CAP-GAMMA'),
    [string]$QueueDir = "$PSScriptRoot/_queue",
    [switch]$AllowReal
)

$ErrorActionPreference = 'Stop'
$python = (Get-Command python -ErrorAction SilentlyContinue) ?? (Get-Command python3 -ErrorAction SilentlyContinue)
if (-not $python) { throw 'Python not found on PATH.' }
$runner = Join-Path $PSScriptRoot 'servitor_capsule.py'
New-Item -ItemType Directory -Force -Path $QueueDir | Out-Null

$procs = @{}
function Start-Capsule([string]$id) {
    $argsList = @($runner, '--capsule', $id, '--queue-dir', $QueueDir)
    if ($AllowReal) { $argsList += '--allow-real' }
    $p = Start-Process -FilePath $python.Source -ArgumentList $argsList -PassThru -NoNewWindow
    $procs[$id] = $p
    Write-Host ("  [+] capsule {0} pid {1}" -f $id, $p.Id) -ForegroundColor Magenta
}

function Dispatch-Task([string]$id, [string]$task) {
    $line = (@{ task = $task; ts = (Get-Date).ToUniversalTime().ToString('o') } | ConvertTo-Json -Compress)
    Add-Content -Path (Join-Path $QueueDir "$id.tasks.jsonl") -Value $line -Encoding utf8
}

Write-Host ''
Write-Host '  \u2042  IMPERIAL IDE :: SERVITOR CAPSULE SUPERVISOR' -ForegroundColor Cyan
Write-Host '  ===============================================' -ForegroundColor DarkMagenta
foreach ($id in $Capsules) { Start-Capsule $id }

Write-Host ''
Write-Host '  Commands:  [s]tatus   [d]ispatch-all   [f]eed <id> <task>   [q]uit' -ForegroundColor Yellow

while ($true) {
    $cmd = Read-Host "`n  supervisor>"
    switch -Regex ($cmd) {
        '^s' {
            foreach ($id in $Capsules) {
                $statePath = Join-Path $QueueDir "$id.state.json"
                if (Test-Path $statePath) {
                    $st = Get-Content $statePath -Raw | ConvertFrom-Json
                    Write-Host ("    {0,-10} {1,-9} done:{2}" -f $st.capsule, $st.state, $st.done) -ForegroundColor Green
                } else {
                    Write-Host ("    {0,-10} (no state yet)" -f $id) -ForegroundColor DarkGray
                }
                # keep-alive: restart if the process died
                if ($procs[$id].HasExited) {
                    Write-Host ("    [!] {0} exited; restarting" -f $id) -ForegroundColor Red
                    Start-Capsule $id
                }
            }
        }
        '^d' {
            $task = Read-Host '    task for ALL capsules'
            foreach ($id in $Capsules) { Dispatch-Task $id $task }
            Write-Host '    dispatched to all capsules' -ForegroundColor Magenta
        }
        '^f' {
            $parts = $cmd -split '\s+', 3
            if ($parts.Count -ge 3) { Dispatch-Task $parts[1] $parts[2]; Write-Host '    fed' -ForegroundColor Magenta }
            else { Write-Host '    usage: f <capsule-id> <task text>' -ForegroundColor Red }
        }
        '^q' {
            foreach ($id in $Capsules) { if (-not $procs[$id].HasExited) { $procs[$id].Kill() } }
            Write-Host '  \u2042 Ave Omnissiah. Supervisor down.' -ForegroundColor Cyan
            return
        }
        default { Write-Host '    unknown command' -ForegroundColor Red }
    }
}
