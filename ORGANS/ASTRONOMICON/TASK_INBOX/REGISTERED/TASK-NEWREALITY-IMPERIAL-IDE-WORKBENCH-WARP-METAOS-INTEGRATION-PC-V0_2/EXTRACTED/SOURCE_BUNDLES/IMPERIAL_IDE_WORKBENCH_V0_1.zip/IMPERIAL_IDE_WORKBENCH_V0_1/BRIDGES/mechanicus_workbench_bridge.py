#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MECHANICUS WORKBENCH BRIDGE  (V0.1)

Thin client that connects the GUI/TUI workbench to the EXISTING Mechanicus
dry-run bridge already shipped in the repo at:
    ORGANS/MECHANICUS/IDE_BRIDGE/mechanicus_ide_bridge.py

This file deliberately does NOT re-implement the tool registry or policy. It:
  1. Locates the live Mechanicus bridge / registries.
  2. Exposes a small, safe API the GUI calls: list_tools, get_capabilities,
     get_policy, dry_run_tool.
  3. Enforces the same boundary: unknown tool => BLOCKED, real execution off
     unless explicitly enabled by the live bridge (never by this client).

If the live bridge is not found (sample mode), it returns bundled sample data
so the GUI is still demonstrable offline.
"""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(HERE)


def _repo_root():
    env = os.environ.get("IMPERIUM_ROOT")
    if env and os.path.isdir(os.path.join(env, "ORGANS")):
        return env
    cur = HERE
    for _ in range(8):
        if os.path.isdir(os.path.join(cur, "ORGANS")) and os.path.isfile(
                os.path.join(cur, "AGENTS.md")):
            return cur
        nxt = os.path.dirname(cur)
        if nxt == cur:
            break
        cur = nxt
    return None


class MechanicusBridge:
    def __init__(self):
        self.root = _repo_root()
        self.live_bridge = None
        if self.root:
            cand = os.path.join(self.root, "ORGANS", "MECHANICUS", "IDE_BRIDGE",
                                "mechanicus_ide_bridge.py")
            if os.path.isfile(cand):
                self.live_bridge = cand

    @property
    def mode(self):
        return "LIVE" if self.live_bridge else "SAMPLE"

    def _sample(self, name):
        path = os.path.join(PKG_ROOT, "BRIDGES", "sample_%s.json" % name)
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        return {}

    def _call_live(self, command, extra=None):
        """Invoke the live bridge as a subprocess in read/dry-run mode only."""
        cmd = [sys.executable, self.live_bridge, command]
        if extra:
            cmd += extra
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True,
                                  timeout=60, cwd=self.root)
            out = (proc.stdout or "").strip()
            try:
                return json.loads(out)
            except json.JSONDecodeError:
                return {"raw": out, "rc": proc.returncode,
                        "stderr": (proc.stderr or "")[-500:]}
        except Exception as exc:
            return {"error": str(exc)}

    def list_tools(self):
        if self.live_bridge:
            return self._call_live("tools")
        return self._sample("tools")

    def get_capabilities(self):
        if self.live_bridge:
            return self._call_live("capabilities")
        return self._sample("capabilities")

    def get_policy(self):
        if self.live_bridge:
            return self._call_live("policy")
        return self._sample("policy")

    def dry_run_tool(self, tool_id, task=""):
        if self.live_bridge:
            return self._call_live("dry-run-tool", ["--tool", tool_id, "--task", task])
        # sample boundary behaviour: unknown tool -> BLOCKED
        known = {t.get("tool_id") for t in self._sample("tools").get("tools", [])}
        if tool_id not in known:
            return {"tool_id": tool_id, "status": "BLOCKED",
                    "reason": "tool_not_registered", "executed": False}
        return {"tool_id": tool_id, "status": "DRY_RUN", "executed": False,
                "plan": "would execute %s for task '%s'" % (tool_id, task)}


if __name__ == "__main__":
    b = MechanicusBridge()
    print(json.dumps({
        "mode": b.mode,
        "root": b.root,
        "tools": b.list_tools(),
        "policy": b.get_policy(),
        "negative_test": b.dry_run_tool("arbitrary.shell", "rm -rf /"),
    }, ensure_ascii=False, indent=2))
