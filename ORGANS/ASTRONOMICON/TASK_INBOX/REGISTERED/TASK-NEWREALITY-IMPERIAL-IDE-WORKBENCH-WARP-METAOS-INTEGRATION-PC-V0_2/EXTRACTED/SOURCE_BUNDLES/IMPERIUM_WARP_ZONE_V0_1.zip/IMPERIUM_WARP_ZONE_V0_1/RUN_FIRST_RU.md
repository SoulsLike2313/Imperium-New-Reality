# RUN FIRST — первый запуск WARP

## 0. Требования
- Python 3.9+ (стандартная библиотека, без внешних зависимостей).
- Для GUI: Tkinter (входит в обычный Python на Windows).

## 1. Распаковка
Положи папку в `ORGANS/IMPERIAL_IDE/WARP/`.

## 2. Переменные окружения (PowerShell)
```powershell
$env:IMPERIUM_ROOT = "E:\IMPERIUM_NEW_GENERATION_NEW_REALITY"
$env:WARP_ROOT     = "E:\IMPERIUM_NEW_GENERATION_NEW_REALITY\WARP\runtime"
```

## 3. Смок-тест (доказательство, что ядро чисто)
```powershell
python warp_smoke.py
```
Ожидаемо: SCENARIO 1 → DISCARD (fake-green), SCENARIO 2 → RELEASE,
в обоих kernel untouched: True, в конце SMOKE RESULT: PASS.

## 4. Посмотреть зону в TUI
```powershell
python UI/warp_tui.py --smoke
```

## 5. Открыть сессию руками (CLI)
```powershell
python LAUNCHER/warp_launcher.py open --task "собрать дашборд" --kind THIRD_PARTY
python LAUNCHER/warp_launcher.py list
python LAUNCHER/warp_launcher.py status --session <ID>
```

## 6. Кнопка WARP (GUI)
```powershell
python UI/warp_gui_panel.py
```
Нажми «▶ ENTER WARP» — откроется сессия, появятся дифы/метрики/лог.

## 7. Авто-старт при задаче
В хук старта задачи IDE:
```python
import sys; sys.path.insert(0, "LAUNCHER")
from warp_autostart_hook import open_for_task
open_for_task(task_descriptor, trigger="auto")
```

## Честно
- GUI и PowerShell не запускались в Linux-сандбоксе (нет дисплея/pwsh).
  Проверь на своём PC. Движок/CLI/TUI/smoke проверены.
