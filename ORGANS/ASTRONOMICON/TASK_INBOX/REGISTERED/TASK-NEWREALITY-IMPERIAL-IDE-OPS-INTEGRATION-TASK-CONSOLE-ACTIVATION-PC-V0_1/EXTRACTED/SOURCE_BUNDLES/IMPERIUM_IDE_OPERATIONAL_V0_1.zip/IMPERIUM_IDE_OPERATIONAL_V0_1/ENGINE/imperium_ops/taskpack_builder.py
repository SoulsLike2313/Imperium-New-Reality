"""taskpack_builder - assemble a registrable taskpack from a TaskIntent.

Generates MANIFEST/TASK_SPEC/ACCEPTANCE_GATES/OUTPUT_REQUIREMENTS/ROUTE/ACK,
builds a deterministic zip + sha256, and runs the same gates Astronomicon will:
language gate, no-BOM, JSON parse, admission precheck.
"""
from __future__ import annotations

import hashlib
import json
import os
import zipfile
from typing import Dict, List

from .task_console import TaskIntent

SCHEMA_VERSION = "imperium.taskpack/1"

REQUIRED_TASKPACK_FILES = [
    "MANIFEST.json",
    "TASK_SPEC.md",
    "ACCEPTANCE_GATES.md",
    "OUTPUT_REQUIREMENTS.md",
    "TASK_ROUTE_MANIFEST_TEMPLATE.json",
    "TASK_START_ACK_TEMPLATE.json",
]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def build_manifest(intent: TaskIntent) -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "task_id": intent.task_id,
        "title": intent.title,
        "created_from_contour": "PC",
        "target_contour": "PC",
        "registration_mode": "ASTRONOMICON_STAGE2_LOCAL_PC_TASKPACK_WITH_BUNDLED_SOURCES",
        "execution_mode": "CONTROLLED_WRITE_WITH_VALIDATED_PUSH",
        "status": "CANDIDATE_NOT_CANON",
        "mission_summary": intent.goal,
        "task_type": intent.task_type,
        "scope": intent.scope,
        "risk": intent.risk,
        "organs_route": intent.organs_route,
        "allowed_write_scope": intent.allowed_write_scope,
        "forbidden_actions": intent.forbidden_actions,
        "push_policy": intent.push_policy,
        "source_bundles": {},
        "remote_contours": {"VM2": "OUT_OF_SCOPE", "VM3": "OUT_OF_SCOPE"},
    }


def render_task_spec(intent: TaskIntent) -> str:
    return (
        f"# TASK_SPEC\n\n"
        f"## Task ID\n{intent.task_id}\n\n"
        f"## Title\n{intent.title}\n\n"
        f"## Goal\n{intent.goal}\n\n"
        f"## Type / Scope / Risk\n{intent.task_type} / {intent.scope} / {intent.risk}\n\n"
        f"## Organs route\n{', '.join(intent.organs_route)}\n\n"
        f"## Allowed write scope\n{', '.join(intent.allowed_write_scope)}\n"
    )


def render_acceptance_gates(intent: TaskIntent) -> str:
    return (
        "# ACCEPTANCE_GATES\n\n"
        "## Gate 1: Language\nDocs RU, code/identifiers EN.\n\n"
        "## Gate 2: No-BOM / JSON parse\nAll JSON parses, no BOM.\n\n"
        "## Gate 3: Compile\npy_compile passes => COMPILE_OK.\n\n"
        "## Gate 4: Smoke\nEnd-to-end smoke PASS (exit 0).\n\n"
        "## Gate 5: Admission\nadmission_precheck returns no blockers.\n\n"
        "## Gate 6: Safety\nAll dangerous flags OFF by default.\n\n"
        "## Gate 7: Anti-fake-green\nNo PASS without receipts.\n\n"
        f"## Gate 8: Scope\nDiff only within: {', '.join(intent.allowed_write_scope)}\n"
    )


def render_output_requirements(intent: TaskIntent) -> str:
    return (
        "# OUTPUT_REQUIREMENTS\n\n"
        "Final owner report MUST contain: task_id, result_summary, artifacts, "
        "evidence_level (>= E3), metrics, tokens_used, cost_usd.\n"
        "No PASS without receipts. UTF-8 no BOM, valid JSON.\n"
    )


def render_route_manifest_template(intent: TaskIntent) -> dict:
    return {
        "schema_version": "imperium.route/1",
        "task_id": intent.task_id,
        "route": [
            {"step": i + 1, "organ": organ, "action": "process", "mode": "dry_run"}
            for i, organ in enumerate(intent.organs_route)
        ],
        "tier_hint": "deterministic",
        "token_budget": 0,
        "confidence_threshold": 0.75,
    }


def render_start_ack_template(intent: TaskIntent) -> dict:
    return {
        "schema_version": "imperium.start_ack/1",
        "task_id": intent.task_id,
        "acknowledged_by": "FILL_EXECUTOR_ID",
        "acknowledged_at": "FILL_ISO8601",
        "contour": "PC",
        "scope_confirmed": intent.allowed_write_scope,
        "forbidden_confirmed": intent.forbidden_actions,
        "start_message": "SERVITOR START: acknowledged scope and forbidden actions; dry-run only.",
    }


def no_bom_check(text: str) -> bool:
    """True if text has no UTF-8 BOM."""
    return not text.startswith("\ufeff")


def language_gate_check(text: str) -> bool:
    """Lightweight: reject obvious placeholder/empty content."""
    return bool(text and text.strip())


def json_parse_check(text: str) -> bool:
    try:
        json.loads(text)
        return True
    except (ValueError, json.JSONDecodeError):
        return False


def _write(path: str, text: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)


def write_taskpack(out_root: str, intent: TaskIntent) -> str:
    """Write the EXTRACTED taskpack tree and return its directory."""
    extracted = os.path.join(out_root, intent.task_id, "EXTRACTED")
    os.makedirs(extracted, exist_ok=True)
    _write(os.path.join(extracted, "MANIFEST.json"),
           json.dumps(build_manifest(intent), ensure_ascii=False, indent=2) + "\n")
    _write(os.path.join(extracted, "TASK_SPEC.md"), render_task_spec(intent))
    _write(os.path.join(extracted, "ACCEPTANCE_GATES.md"), render_acceptance_gates(intent))
    _write(os.path.join(extracted, "OUTPUT_REQUIREMENTS.md"), render_output_requirements(intent))
    _write(os.path.join(extracted, "TASK_ROUTE_MANIFEST_TEMPLATE.json"),
           json.dumps(render_route_manifest_template(intent), ensure_ascii=False, indent=2) + "\n")
    _write(os.path.join(extracted, "TASK_START_ACK_TEMPLATE.json"),
           json.dumps(render_start_ack_template(intent), ensure_ascii=False, indent=2) + "\n")
    _write(os.path.join(extracted, "README.md"),
           f"# {intent.task_id}\n\n{intent.title}\n\nStatus: CANDIDATE_NOT_CANON\n")
    return extracted


def build_zip(extracted: str, zip_path: str) -> Dict:
    """Zip the extracted tree (excluding pycache/.pyc) and return file/byte/sha."""
    os.makedirs(os.path.dirname(zip_path), exist_ok=True)
    files = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dirs, fs in os.walk(extracted):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for f in sorted(fs):
                if f.endswith(".pyc"):
                    continue
                full = os.path.join(dp, f)
                arc = os.path.relpath(full, extracted)
                z.write(full, arc)
                files += 1
    data = open(zip_path, "rb").read()
    return {"files": files, "bytes": len(data), "sha256": sha256_bytes(data)}


def admission_precheck(extracted: str) -> List[str]:
    """Return blockers that would stop Astronomicon admission. Empty == clean."""
    blockers: List[str] = []
    for name in REQUIRED_TASKPACK_FILES:
        path = os.path.join(extracted, name)
        if not os.path.isfile(path):
            blockers.append(f"missing required file: {name}")
            continue
        with open(path, "r", encoding="utf-8") as fh:
            text = fh.read()
        if not no_bom_check(text):
            blockers.append(f"BOM detected in {name}")
        if not language_gate_check(text):
            blockers.append(f"empty/placeholder content in {name}")
        if name.endswith(".json") and not json_parse_check(text):
            blockers.append(f"invalid JSON in {name}")
    return blockers
