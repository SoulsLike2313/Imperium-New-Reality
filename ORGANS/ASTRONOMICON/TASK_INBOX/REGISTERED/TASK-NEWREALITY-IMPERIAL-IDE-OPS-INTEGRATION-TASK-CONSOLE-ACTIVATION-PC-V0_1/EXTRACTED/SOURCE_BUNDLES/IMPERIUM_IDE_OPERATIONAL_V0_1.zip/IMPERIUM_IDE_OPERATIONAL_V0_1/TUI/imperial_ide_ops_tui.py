#!/usr/bin/env python3
"""imperial_ide_ops_tui - text shell over the operational engine.

The fast working surface: a captain's-bridge menu where the owner can run the
full task loop from inside the IDE. Reads stdin; in non-interactive mode it
prints the menu and exits cleanly so it is smoke-testable.
"""
from __future__ import annotations

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ENGINE = os.path.normpath(os.path.join(_HERE, "..", "ENGINE"))
if _ENGINE not in sys.path:
    sys.path.insert(0, _ENGINE)

from imperium_ops import (  # noqa: E402
    astronomicon_register as astro,
    git_closure,
    launch_card as lc,
    lifecycle,
    safety_gate,
    task_console,
    taskpack_builder as tpb,
)

MENU = [
    ("1", "Dashboard"),
    ("2", "Task Console"),
    ("3", "Astronomicon"),
    ("4", "Mechanicus"),
    ("5", "WARP"),
    ("6", "MetaOS"),
    ("7", "Servitors"),
    ("8", "Reports"),
    ("9", "Receipts"),
    ("10", "Governance"),
    ("11", "Git / Push"),
    ("12", "Extensions"),
    ("13", "Settings"),
    ("q", "Quit"),
]


def _repo_root() -> str:
    return os.path.abspath(os.environ.get("IMPERIUM_ROOT", os.getcwd()))


def render_menu() -> str:
    lines = ["", "=== IMPERIAL IDE :: OPERATIONAL CONSOLE ==="]
    for key, label in MENU:
        lines.append(f"  [{key}] {label}")
    lines.append("===========================================")
    return "\n".join(lines)


def dashboard(repo: str) -> str:
    gs = git_closure.git_status(repo)
    state = safety_gate.load_safety(repo)
    rep = safety_gate.safety_report(state)
    regs = astro.list_registered(repo)
    out = ["-- DASHBOARD (captain's bridge) --",
           f"repo        : {repo}",
           f"git         : {gs}",
           f"registered  : {len(regs)} task(s)",
           "safety      :"]
    for k, v in rep.items():
        out.append(f"   {k}: {v}")
    return "\n".join(out)


def task_console_flow(repo: str) -> str:
    """Interactive task creation -> taskpack -> register -> launch card -> lifecycle."""
    title = input("Title: ").strip()
    goal = input("Goal: ").strip() or title
    ttype = input("Type (blank = auto): ").strip() or None
    scope = input("Scope [IMPERIAL_IDE]: ").strip() or "IMPERIAL_IDE"
    risk = input("Risk [CONTROLLED_WRITE]: ").strip() or "CONTROLLED_WRITE"
    push = input("Push policy [NO_PUSH]: ").strip() or "NO_PUSH"
    intent = task_console.new_task(title=title, goal=goal, task_type=ttype,
                                   scope=scope, risk=risk, push_policy=push)
    out_root = os.path.join(repo, "STAGING", "TASKPACKS")
    print(f"Task id: {intent.task_id}")
    if input("Run full lifecycle (dry-run)? [y/N]: ").strip().lower() == "y":
        state = safety_gate.load_safety(repo)
        result = lifecycle.run_lifecycle(repo, intent, out_root, state=state, dry_run=True)
        return lifecycle.render_progress(result) + f"\n\nVERDICT: {result.verdict}"
    extracted = tpb.write_taskpack(out_root, intent)
    reg = astro.register(repo, extracted, intent, dry_run=True)
    card = lc.build_launch_card(intent, reg.registered_path, reg.admitted, reg.sha256)
    return lc.render_launch_card_text(card)


def _static_panel(name: str) -> str:
    panels = {
        "Astronomicon": "registered tasks, admission/resolver receipts, re-register, search by id",
        "Mechanicus": "tool/capability registry, doctor, validate-json, compile-python, dry-run tool",
        "WARP": "warp new/list/open/status/smoke/gate/release-candidate/bundle-gate",
        "MetaOS": "route/context/budget/smoke/servitor/bundle-gate/chronicle",
        "Servitors": "Alpha/Beta/Gamma status, queue, dry-run only (real execution blocked)",
        "Reports": "latest/by-task/by-organ/find-blocks/find-warnings/next-task",
        "Receipts": "validate schema, missing fields, fake-green risk, link to task/commit",
        "Governance": "Passport/Constitution/AGENTS.md, authority order, policy conflicts",
        "Git / Push": "status/diff/scope-check/secret-check/commit/push (post-validation only)",
        "Extensions": "installed/candidate, permissions, validate manifest, enable/disable",
        "Settings": "repo selector, theme, safety flags (all dangerous flags OFF by default)",
    }
    return f"-- {name} --\n  {panels.get(name, 'panel ready')}"


def run(interactive: bool = True) -> int:
    repo = _repo_root()
    print(render_menu())
    if not interactive or not sys.stdin.isatty():
        # Non-interactive (smoke/CI): show dashboard once and exit cleanly.
        print(dashboard(repo))
        return 0
    while True:
        choice = input("select> ").strip().lower()
        if choice == "q":
            print("Exiting Imperial IDE console.")
            return 0
        elif choice == "1":
            print(dashboard(repo))
        elif choice == "2":
            print(task_console_flow(repo))
        else:
            label = dict(MENU).get(choice)
            print(_static_panel(label) if label else "Unknown option.")
        print(render_menu())


if __name__ == "__main__":
    raise SystemExit(run(interactive=True))
