# Next Owner Action

1. Передать Servitor следующий taskpack: `TASK-NEWGEN-STAGE3-FIRST-REAL-USE-GHOST-EVOLVE-MICROPILOT-PC-V0_1`.
2. Требовать старт только через Astronomicon task ID / `start task`.
3. Не разрешать clean PASS до Inquisitor + Speculum review.
4. Держать WARP, IDE visual release и freelance-production claims закрытыми.
