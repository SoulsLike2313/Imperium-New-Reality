# Blueprint: Stage3 First Real-Use Ghost_Evolve Micro-Pilot

Status: `CANDIDATE_BLUEPRINT_FROM_INQUISITOR_REVIEW`

## Purpose

Run the first small useful task through the already-created Astronomicon Task Entry Corridor and 8-organ participation form.

This is not WARP, not freelance production, and not IDE visual release. It is a controlled proof that a real task can enter IMPERIUM through task ID and produce evidence through organs.

## Required preflight

1. Confirm HEAD starts from `d7906a40e2a001e1d98c0f7a830739d0c09ce01d` or later clean HEAD.
2. Confirm `git status --short` is clean.
3. Confirm Astronomicon task inbox / registry / resolver are available.
4. Confirm 8 organ participation packets are readable.
5. Confirm dirty staging goes outside repo or is auto-cleaned.

## Required outputs

- `ASTRONOMICON_TASK_ENTRY_ACK.json`
- `EIGHT_ORGAN_PARTICIPATION_RUNTIME_RECEIPT.json`
- `REAL_USE_MICROPILOT_SCOPE.md`
- `CLAIM_LEDGER.jsonl`
- `CAPABILITY_SPLIT_RECEIPT.json`
- `RUNTIME_OUTPUT_CLASSIFICATION.json`
- `HARD_RED_TEAM_VERDICT.json`
- `FINAL_OWNER_SUMMARY_RU.md`
- `NEXT_PIPELINE_HANDOFF.json`

## Hard gates

- No clean PASS without independent review.
- No WARP claim.
- No IDE visual release claim.
- No runtime files left dirty without classification.
- No broad task; pilot must be small and replayable.

## Candidate pilot ideas

1. Register and resolve a tiny synthetic-but-useful taskpack through Astronomicon, then execute a real script-first check.
2. Produce a tiny organ participation report for one existing report bundle.
3. Run a tiny task that updates only a candidate learning backlog from a known previous issue.

Recommended: option 1, because it directly tests task-entry route.
