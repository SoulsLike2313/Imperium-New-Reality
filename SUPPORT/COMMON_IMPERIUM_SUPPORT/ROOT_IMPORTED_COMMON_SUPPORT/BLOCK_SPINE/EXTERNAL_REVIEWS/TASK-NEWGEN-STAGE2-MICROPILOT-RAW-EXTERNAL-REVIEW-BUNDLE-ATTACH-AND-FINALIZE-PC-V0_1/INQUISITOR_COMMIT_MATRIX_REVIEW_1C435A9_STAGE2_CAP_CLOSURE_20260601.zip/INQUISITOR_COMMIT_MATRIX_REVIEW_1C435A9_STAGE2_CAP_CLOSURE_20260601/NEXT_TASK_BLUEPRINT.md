# Next Task Blueprint

## Preferred narrow follow-up

`TASK-NEWGEN-STAGE2-MICROPILOT-RAW-EXTERNAL-REVIEW-BUNDLE-ATTACH-AND-FINALIZE-VM3-V0_1`

## Goal

Close or explicitly downgrade the remaining external-finalization cap by attaching raw external Inquisitor/Speculum bundles or equivalent signed external references.

## Required outputs

- `raw_external_review_bundle_inventory.json`
- `external_review_reference_verification_receipt.json`
- `cap_external_finalization_final_decision.json`
- `claim_ledger.jsonl`
- `hard_red_team_verdict.json`
- `final_owner_summary_ru.md`
- `commit_push_receipt.json`

## Pass gates

- Raw external bundles or signed references exist and hash-check.
- Review target head is exactly `f3123e5b089821487d9891b156351ba4006f349c` or explicitly adjudicated.
- If raw evidence is missing, verdict must stay `PASS_WITH_WARNINGS` and cap must remain `NARROWED` or become `CARRIED`, never fake-CLOSED.

## Forbidden

- No WARP claim.
- No IDE visual release claim.
- No global clean PASS based only on synthesis.
