# Source register

- `github_commit_f3123e5`: https://github.com/SoulsLike2313/Imperium-/commit/f3123e5b089821487d9891b156351ba4006f349c
- `github_commit_2b9b3d1`: https://github.com/SoulsLike2313/Imperium-/commit/2b9b3d1
- `github_commit_5fe85a5`: https://github.com/SoulsLike2313/Imperium-/commit/5fe85a57e76b9e05ab04dcb067191945d9f81b8b
- `report_directory`: https://github.com/SoulsLike2313/Imperium-/tree/f3123e5b089821487d9891b156351ba4006f349c/IMPERIUM_NEW_GENERATION/BLOCK_SPINE/REPORTS/TASK-NEWGEN-STAGE2-MICROPILOT-VM3-CONTEXT-PACK-EXECUTION-V0_1
- `raw_context_pack_consumption_receipt`: https://raw.githubusercontent.com/SoulsLike2313/Imperium-/f3123e5b089821487d9891b156351ba4006f349c/IMPERIUM_NEW_GENERATION/BLOCK_SPINE/REPORTS/TASK-NEWGEN-STAGE2-MICROPILOT-VM3-CONTEXT-PACK-EXECUTION-V0_1/context_pack_consumption_receipt.json
- `raw_context_economy_delta`: https://raw.githubusercontent.com/SoulsLike2313/Imperium-/f3123e5b089821487d9891b156351ba4006f349c/IMPERIUM_NEW_GENERATION/BLOCK_SPINE/REPORTS/TASK-NEWGEN-STAGE2-MICROPILOT-VM3-CONTEXT-PACK-EXECUTION-V0_1/before_after_context_economy_delta.json
- `raw_hard_red_team_verdict`: https://raw.githubusercontent.com/SoulsLike2313/Imperium-/f3123e5b089821487d9891b156351ba4006f349c/IMPERIUM_NEW_GENERATION/BLOCK_SPINE/REPORTS/TASK-NEWGEN-STAGE2-MICROPILOT-VM3-CONTEXT-PACK-EXECUTION-V0_1/hard_red_team_verdict.json
- `raw_commit_push_receipt`: https://raw.githubusercontent.com/SoulsLike2313/Imperium-/f3123e5b089821487d9891b156351ba4006f349c/IMPERIUM_NEW_GENERATION/BLOCK_SPINE/REPORTS/TASK-NEWGEN-STAGE2-MICROPILOT-VM3-CONTEXT-PACK-EXECUTION-V0_1/commit_push_receipt.json