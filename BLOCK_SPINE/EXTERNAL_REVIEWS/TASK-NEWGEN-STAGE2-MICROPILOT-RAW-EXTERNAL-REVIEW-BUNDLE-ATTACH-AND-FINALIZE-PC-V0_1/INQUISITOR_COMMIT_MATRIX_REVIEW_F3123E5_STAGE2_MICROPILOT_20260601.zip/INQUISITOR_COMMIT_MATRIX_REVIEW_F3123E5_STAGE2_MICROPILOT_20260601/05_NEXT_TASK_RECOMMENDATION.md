# Next task recommendation

`TASK-NEWGEN-STAGE2-MICROPILOT-EXTERNAL-FINALIZATION-AND-INDEPENDENT-REPLAY-CAP-CLOSURE-VM3-V0_1`

Objective: Close or narrow the remaining external-finalization and independent-replay caps for the Stage2 context-pack micro-pilot, without claiming IDE/WARP/freelance readiness.
