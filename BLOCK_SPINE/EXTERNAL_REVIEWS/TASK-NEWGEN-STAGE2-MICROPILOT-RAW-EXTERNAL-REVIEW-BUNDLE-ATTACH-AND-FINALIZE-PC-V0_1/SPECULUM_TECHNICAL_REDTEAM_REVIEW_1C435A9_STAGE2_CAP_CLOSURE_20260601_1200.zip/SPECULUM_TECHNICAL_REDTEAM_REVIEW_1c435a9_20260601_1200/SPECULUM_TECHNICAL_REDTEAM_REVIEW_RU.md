# SPECULUM TECHNICAL RED-TEAM REVIEW — `1c435a9`

**Task:** `TASK-NEWGEN-STAGE2-MICROPILOT-EXTERNAL-FINALIZATION-AND-INDEPENDENT-REPLAY-CAP-CLOSURE-VM3-V0_1`  
**Evidence pack commit:** `f771403a`  
**Closure receipt commit:** `0feda137dfed679b78a51dc9d3f25ad097f16d80`  
**Summary normalization:** `c24bb511`  
**Final HEAD:** `1c435a944ed6fbf8bbe5ef7c24a0b8a29c1c9860`  
**Verdict:** `PASS_WITH_WARNINGS__INDEPENDENT_REPLAY_CAP_CLOSED__EXTERNAL_FINALIZATION_NARROWED__BLOCK_CLEAN_PASS_STAGE_IDE_WARP_AND_RAW_EXTERNAL_BUNDLE_GAP`

## 0. Brutal verdict

This task materially improves the previous Stage2 context-pack proof. The local isolated replay is real and closes the “no local independent replay in review environment” cap. The context-pack consumption result is stable: 34 mandatory files, 34 read, 0 missing, no broad read, same 40,448 character payload.

But clean PASS remains blocked. External finalization is only `NARROWED`, not closed; Stage1/IDE/WARP caps remain carried; and the final HEAD is summary wording alignment, not the substantive evidence bundle.

## 1. Commit truth

```json
{
  "evidence_pack_f771403": {
    "files_changed": 49,
    "additions": 1797,
    "deletions": 6,
    "classification": "evidence pack: cap closure decision, independent replay, external finalization receipt, hard red-team, learning cards, registered taskpack."
  },
  "final_1c435a9": {
    "files_changed": 2,
    "additions": 1,
    "deletions": 1,
    "classification": "owner summary wording alignment + tiny zip placeholder; not implementation."
  }
}
```

## 2. Positive evidence

- Independent replay is real and local-isolated: replay_mode=LOCAL_GIT_WORKTREE_ISOLATED_REPLAY, replay_verdict=PASS.
- Context-pack consumption replay matched previous receipt: 34 mandatory, 34 read, 0 missing, 40,448 chars, broad_read_detected=false, summary_match=true.
- CAP_NO_LOCAL_INDEPENDENT_REPLAY_IN_REVIEW_ENVIRONMENT is CLOSED.
- CAP_EXTERNAL_FINALIZATION_RECEIPT_MISSING_OR_NEEDS_FOLLOWUP is at least NARROWED by external_finalization_receipt and owner-provided review synthesis.
- Hard red-team status remains PASS_WITH_WARNINGS, not fake clean PASS.
- Final summary explicitly records head chain f771403 -> 0feda137 -> c24bb511 and sync confirmation.

## 3. Top blockers

### B1 — External finalization cap is narrowed, not closed

Severity: `BLOCK_CLEAN_PASS`

CAP_EXTERNAL_FINALIZATION_RECEIPT_MISSING_OR_NEEDS_FOLLOWUP moved to NARROWED; raw external review bundles or equivalent signed references are still required to close it.

### B2 — Stage/IDE/WARP caps are carried

Severity: `BLOCK_CLEAN_PASS`

CAP_STAGE1_WITH_WARNINGS_ONLY, CAP_NO_IDE_VISUAL_RELEASE_YET, CAP_NO_WARP_RUNTIME, and CAP_DIRTY_START_OWNER_APPROVED_CONTINUATION remain carried.

### B3 — Final HEAD 1c435a9 is summary alignment, not evidence implementation

Severity: `WARN_HEAD_ROLE`

Substantive evidence is f771403; 1c435a9 only aligns final_owner_summary wording and adds a tiny 113-byte output zip entry.


## 4. Technical adjusted delta

```json
{
  "independent_replay_closure_delta": "+28",
  "context_pack_evidence_confidence_delta": "+18",
  "external_finalization_semantics_delta": "+10",
  "cap_hygiene_delta": "+14",
  "owner_sanctum_visual_delta": "+0",
  "warp_runtime_delta": "+0",
  "overall_delta": "+17",
  "why_not_higher": [
    "External finalization is narrowed, not closed.",
    "Stage1/IDE/WARP caps remain carried.",
    "Final HEAD is wording alignment, not implementation.",
    "No IDE/Sanctum/WARP/API runtime capability was delivered.",
    "Registered taskpack artifacts remain in repo and require retention discipline."
  ]
}
```

## 5. File classification

### KEEP_LIST
- `cap_closure_decision.json`
- `independent_replay_receipt.json`
- `independent_replay_context_pack_consumption_receipt.json`
- `external_finalization_receipt.json`
- `hard_red_team_verdict.json`
- `claim_ledger.jsonl`
- `astronomicon_positive_controls_learning_card.md`
- `taskpack_admission_regression_fixtures.json`
- `ghost_evolve_learning_delta.json`
- `final_owner_summary_ru.md`

### QUARANTINE_LIST
- TASK-..._OUTPUTS.zip is 113 bytes in final commit; keep only if it is an index/placeholder, otherwise replace with real external artifact handling.
- TASK_INBOX/REGISTERED/<TASK_ID>/TASKPACK.zip after canonical sample is superseded.
- TASK_INBOX/REGISTERED/<TASK_ID>/EXTRACTED/** after review cycle.
- manual_read_log.jsonl after one audit cycle unless used as replay proof.

### DELETE_IN_NEXT_CLEANUP_LIST
- No pid/log/cache junk visible in reviewed commit pages.
- Delete duplicate registered taskpack extractions when retention policy selects canonical sample.

### REWRITE_REQUIRED_LIST
- Close or explicitly freeze CAP_EXTERNAL_FINALIZATION_RECEIPT_MISSING_OR_NEEDS_FOLLOWUP with raw external bundles/signed references.
- Separate evidence_pack_head, closure_receipt_head, summary_normalization_head and final_head in future summary schema.
- Do not use 113-byte output zip as substitute for actual review artifact bundle.
- Next task should convert context-pack replay into a blocking budget gate.

## 6. Kill / freeze / accelerate

```json
{
  "kill": [
    "Clean PASS wording",
    "Claiming external finalization closed",
    "Treating final 1c435a9 as implementation evidence",
    "IDE/WARP/runtime claims"
  ],
  "freeze": [
    "IDE visual work",
    "WARP/API/runtime lanes",
    "Further report-bundle growth without budget gate"
  ],
  "accelerate": [
    "Context-pack budget gate",
    "External evidence bundle closure",
    "Retention policy enforcement for registered taskpacks",
    "One more VM3 micro-pilot using replay-closed context pack"
  ]
}
```

## 7. Next task

`TASK-NEWGEN-BLOCK-SPINE-CONTEXT-BUDGET-GATE-AND-EXTERNAL-EVIDENCE-CLOSURE-VM3-V0_1`

Acceptance should require:
1. blocking context budget threshold;
2. proof that 34-file context pack remains sufficient;
3. raw external bundle or signed reference policy;
4. retention handling for registered taskpack payloads;
5. explicit head taxonomy;
6. no clean PASS while Stage1/IDE/WARP caps remain.

## 8. Final Owner-facing judgement

Good: independent replay is no longer hypothetical. Bad: external finalization is still not fully closed, and the final commit is only wording alignment. The next task should turn context replay into an enforced budget gate, not another report layer.
